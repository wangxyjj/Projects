# test the RWLR model 
from RWLSTM_lib import IO_Data
import numpy as np
from numpy import random 
import math
from RWLR_support import RWLR_Model,get_initU, normal_col_l2,RWLR_Model_Betta,Model_Controlling
from Reweight_accessories import residue,weight


"""
 IO setup
"""
ver = 1

test_data_IO = IO_Data(version = ver,fout_name = 'data_RWLR_Basic_v')

#fin_mat = '/Users/XiangyuW/Google Drive/Research2015/SNMFUKmeans/Code/USPSHandwritten/HandW_28x28.mat'
#fin_mat = '/Users/XiangyuW/Google Drive/Research2015/ReweightMF/Code/Python/testdata/data_RWLR_train_3000.mat'
#dataset_name = 'Handwritten'

#random.seed(123456789)

random_pick = False
svd_initial = True

if random_pick:
	dataset_name = 'Handwritten'
	#dataset_name = 'tf_minist'
	fin_mat = '/Users/XiangyuW/Google Drive/Research2015/SNMFUKmeans/Code/USPSHandwritten/HandW_28x28.mat'
	raw_data_train,raw_label_train,raw_data_test,raw_label_test = test_data_IO.use_dataset(dataset_name,fin_mat)
	data = raw_data_train.T
	output = {'fea':raw_data_train,'gnd':raw_label_train}
else:
	dir_path = '/Users/XiangyuW/Google Drive/Research2015/ReweightMF/Code/Python/testdata/'
	#fin_name = 'MINIST_55000_train.mat'
	fin_name = 'data_RWLR_train_3000'
	fin_mat = dir_path+fin_name
	raw_data = test_data_IO.create_data_hw(fin_mat)
	data = raw_data[0].T
	output ={}
	
#data = data[:,:10000]

"""
 Set parameters
"""

dim,n_points = data.shape

w_kernel = 'TruthVector'
par_kernel = 'PartialTruthVector'

k = 14**2
print('\nThe projected low rank is ',k)
n_minibatch = 10
init_portion = 0.2

output.update({
			'k':k, 'dim':dim, 
			'n_points':n_points, 
			'n_minibatch':n_minibatch,
			'weight_kernel':w_kernel,
			'partial_kernel':par_kernel,
			'init_portion':init_portion
			})

"""
 Initialization
"""

if svd_initial:
	U0,idexes0,_ = get_initU(data,init_portion,k,random_seed=12356)
else:
	#random.seed(1346)
	mu = np.zeros(dim)
	sigma = np.identity(dim)
	U0 = random.multivariate_normal(mu,sigma,k).T
	U0 = normal_col_l2(U0)
	idexes0 = np.arange(n_points)
	#W0 = weight(data,U0,0.001)
	#err0, Mk0 = residue(data,U0,np.dot(U0.T,data),W0)

"""
 Define model
"""
max_iters = 20

test_model = RWLR_Model(data, U0, idexes0, delta_err_min =0.001,n_iters=max_iters)

betta_parameters = Model_Controlling(momentum = True,momentum_para = (0.9,1))
test_model_betta = RWLR_Model_Betta(data, U0, idexes0, delta_err_min =0.001,n_iters=max_iters)

"""
 Run test
"""

version = 16
'''
test_data_IO.update_fout('MINIST_RWLR_v', v = version)
U,g,err_list,err_g_list = test_model.apply_RW_Basic_FGD(w_kernel, par_kernel,adjust_on = False)
output.update({ 'U0': U0,
				'U' : U,
				'g' : g,
				'err_list':err_list,
				'err_g_list':err_g_list, 
				'fout_name':test_data_IO.fout
				})

test_data_IO.save_data(output)
'''
test_model_betta.n_iters = 400

test_data_IO.update_fout('MINIST_ARWLR_v', v = version)
U,g,err_list,err_g_list = test_model_betta.apply_RW_Basic_FGD(w_kernel, par_kernel,betta_parameters)
output.update({ 'U0': U0,
				'U' : U,
				'g' : g,
				'err_list':err_list,
				'err_g_list':err_g_list, 
				'fout_name':test_data_IO.fout
				})

test_data_IO.save_data(output)

"""
test_data_IO.update_fout('MINIST_RWLR_Classic_v',v= version)
U,g,err_list,err_g_list = test_model.apply_RW_Basic_FGD(w_kernel, par_kernel, adjust_on = False)

output.update({ 'U0': U0,
				'U' : U,
				'g' : g,
				'err_list':err_list,
				'err_g_list':err_g_list 
				
				})
test_data_IO.save_data(output)


#test_data_IO.update_fout('data_RWLR_SGD_v',v = 2)
#U,g,err_list = test_model.apply_RW_SGD_FGD_FullW(w_kernel,par_kernel,n_minibatch)


test_data_IO.update_fout('data_RWLR_SGD_Classic_v',v = version)
U,g,err_list = test_model.apply_RW_SGD_FGD_FullW(w_kernel,par_kernel,n_minibatch,adjust_on=False)
output.update({ 'U0': U0,
				'U' : U,
				'g' : g,
				'err_list':err_list
				
				})

test_data_IO.save_data(output)

#test_data_IO.update_fout('data_RWLR_SGD_NAG_v')
#U,theta,g,err_list = test_model.apply_RW_SGD_M_FGD(w_kernel,par_kernel,n_minibatch, NAG_on = True)


#test_data_IO.update_fout('data_RWLR_SGD_CM_v',v = 2)
#U,theta,g,err_list = test_model.apply_RW_SGD_M_FGD(w_kernel,par_kernel,n_minibatch)

#test_data_IO.update_fout('data_RWLR_SGD_ShortW_CM_v',v = 2)
#U,g,err_list = test_model.apply_RW_SGD_FGD_ShortW(w_kernel,par_kernel,n_minibatch, adjust_on=True)

'''
output.update({ 'U0': U0,
				'U' : U,
				'g' : g,
				'err_list':err_list,
				'err_g_list':err_g_list 
				
				})

test_data_IO.save_data(output)
'''
"""